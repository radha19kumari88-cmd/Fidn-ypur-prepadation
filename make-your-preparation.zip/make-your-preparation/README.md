# Make your preparation

A Pen created on CodePen.

Original URL: [https://codepen.io/Radha-Kumari-the-selector/pen/JoXBVPo](https://codepen.io/Radha-Kumari-the-selector/pen/JoXBVPo).

